
/**
 * Write a description of class muffins here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class muffins
{
    public static void main (String Args [])
    {
        new muffins ();
    }
    
    public muffins ()
    {
        System.out.println ("Welcome to Millie's Marvelous Muffins");
        
        System.out.println ("\n**If you like muffins, ours are marvelous**");
        
        int muffins = IBIO.inputInt ("\nHow many muffins would you like?");
        int cost = 1;
        if (muffins<=9 )
            cost = 5;
        else if ((muffins>9)&&(muffins<=19))
            cost = 3;
        else if ((muffins>19)&&(muffins<=39))
            cost = 2;
        else if (muffins > 40)
            cost = 1;
        System.out.println ("The cost per muffin is $" +cost);
        int total = cost*muffins;
        System.out.println ("Your total is $ " +total);
    }
}